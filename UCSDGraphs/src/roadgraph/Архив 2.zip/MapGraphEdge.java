package roadgraph;

/**
 * A class to represent a road between two intersections as an edge of MapGraph.
 * @author Oleksandr Pokras
 *
 */
	class MapGraphEdge {
	private String roadName;
	private String roadType;
	private double length;
	private MapGraphNode startNode;
	private MapGraphNode endNode;
	/**
	 * Create a new road between two intersections (MapGraphNodes)
	 * and represent it as an edge in the graph.
	 * @param from The starting point of the edge
	 * @param to The ending point of the edge
	 * @param roadName The name of the road
	 * @param roadType The type of the road
	 * @param length The length of the road, in km 
	 */
	MapGraphEdge (MapGraphNode fromNode, MapGraphNode toNode,
			String roadName, String roadType, double length) {
		this.startNode=fromNode;
		this.endNode=toNode;
		this.roadName=roadName;
		this.roadType=roadType;
		this.length=length;		
	}
	
	//Getters for local variables
	
	/**
	 * @return the road's starting node
	 */
	public MapGraphNode getStartNode() {
		return startNode;
	}

	/**
	 * @return the road's ending node
	 */
	public MapGraphNode getEndNode() {
		return endNode;
	}

	/**
	 * @return the road's name
	 */
	public String getRoadName() {
		return roadName;
	}
	/**
	 * @return the road's type
	 */
	public String getRoadType() {
		return roadType;
	}

	/**
	 * @return the road's length in km
	 */
	public double getLength() {
		return length;
	}
	
}
